# Salat Time BD - Native Android Application

একটি সম্পূর্ণ নেটিভ অ্যান্ড্রয়েড অ্যাপ্লিকেশন (Kotlin & Jetpack Compose)।

## অ্যান্ড্রয়েড স্টুডিওতে চালানোর নিয়ম:
1. এই ফোল্ডারটি আনজিপ করুন।
2. Android Studio (Ladybug / Koala বা নতুন) ওপেন করুন।
3. 'Open' এ ক্লিক করে 'SalatTimeBD-Android' ফোল্ডার সিলেক্ট করুন।
4. Gradle Sync সম্পন্ন হওয়ার পর রান (Run) বাটনে চাপুন অথবা APK বিল্ড করুন।
