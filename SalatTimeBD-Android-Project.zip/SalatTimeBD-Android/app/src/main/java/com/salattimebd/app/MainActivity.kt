package com.salattimebd.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.salattimebd.app.alarm.PrayerAlarmScheduler
import com.salattimebd.app.data.preferences.UserPreferencesRepository
import com.salattimebd.app.data.preferences.UserSettings
import com.salattimebd.app.data.repository.DailyPrayerData
import com.salattimebd.app.data.repository.PrayerRepository
import com.salattimebd.app.data.repository.Resource
import com.salattimebd.app.ui.screens.DiagnosticsScreen
import com.salattimebd.app.ui.screens.HomeScreen
import com.salattimebd.app.ui.screens.SettingsScreen
import com.salattimebd.app.ui.theme.SalatTimeBDTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var prayerRepo: PrayerRepository
    private lateinit var prefsRepo: UserPreferencesRepository
    private lateinit var alarmScheduler: PrayerAlarmScheduler
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var testMediaPlayer: MediaPlayer? = null
    private var activeCustomAudioPrayerId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prayerRepo = PrayerRepository(this)
        prefsRepo = UserPreferencesRepository(this)
        alarmScheduler = PrayerAlarmScheduler(this)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        setContent {
            SalatTimeBDTheme {
                val navController = rememberNavController()
                val userSettings by prefsRepo.userSettingsFlow.collectAsState(initial = UserSettings())
                var prayerState by remember { mutableStateOf<Resource<DailyPrayerData>>(Resource.Loading) }

                // Audio Picker Launcher for custom Adhan file
                val audioPickerLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.GetContent()
                ) { uri: Uri? ->
                    if (uri != null && activeCustomAudioPrayerId != null) {
                        lifecycleScope.launch {
                            val id = activeCustomAudioPrayerId!!
                            val oldConfig = when (id) {
                                "fajr" -> userSettings.fajrAlarm
                                "dhuhr" -> userSettings.dhuhrAlarm
                                "asr" -> userSettings.asrAlarm
                                "maghrib" -> userSettings.maghribAlarm
                                else -> userSettings.ishaAlarm
                            }
                            prefsRepo.updateAlarmConfig(
                                id,
                                oldConfig.copy(customAudioUri = uri.toString(), soundMode = "custom_adhan")
                            )
                            Toast.makeText(this@MainActivity, "আজান অডিও সংরক্ষিত হয়েছে", Toast.LENGTH_SHORT).show()
                        }
                    }
                }

                LaunchedEffect(userSettings.latitude, userSettings.longitude, userSettings.calculationMethodId, userSettings.asrSchool) {
                    prayerState = Resource.Loading
                    val result = prayerRepo.getPrayerTimes(
                        latitude = userSettings.latitude,
                        longitude = userSettings.longitude,
                        locationName = userSettings.selectedDistrict,
                        methodId = userSettings.calculationMethodId,
                        schoolId = userSettings.asrSchool,
                        forceRefresh = false
                    )
                    prayerState = result

                    if (result is Resource.Success) {
                        val configs = mapOf(
                            "fajr" to userSettings.fajrAlarm,
                            "dhuhr" to userSettings.dhuhrAlarm,
                            "asr" to userSettings.asrAlarm,
                            "maghrib" to userSettings.maghribAlarm,
                            "isha" to userSettings.ishaAlarm
                        )
                        alarmScheduler.scheduleAllPrayers(result.data.timings, configs)
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    NavHost(navController = navController, startDestination = "home") {
                        composable("home") {
                            HomeScreen(
                                prayerDataState = prayerState,
                                userSettings = userSettings,
                                onManualRefresh = {
                                    lifecycleScope.launch {
                                        prayerState = Resource.Loading
                                        prayerState = prayerRepo.getPrayerTimes(
                                            latitude = userSettings.latitude,
                                            longitude = userSettings.longitude,
                                            locationName = userSettings.selectedDistrict,
                                            methodId = userSettings.calculationMethodId,
                                            schoolId = userSettings.asrSchool,
                                            forceRefresh = true
                                        )
                                    }
                                },
                                onNavigateToSettings = { navController.navigate("settings") },
                                onNavigateToDiagnostics = { navController.navigate("diagnostics") },
                                onAlarmToggle = { id, enabled ->
                                    lifecycleScope.launch {
                                        val oldConfig = when (id) {
                                            "fajr" -> userSettings.fajrAlarm
                                            "dhuhr" -> userSettings.dhuhrAlarm
                                            "asr" -> userSettings.asrAlarm
                                            "maghrib" -> userSettings.maghribAlarm
                                            else -> userSettings.ishaAlarm
                                        }
                                        prefsRepo.updateAlarmConfig(id, oldConfig.copy(enabled = enabled))
                                    }
                                },
                                onSaveAlarmConfig = { id, updatedConfig ->
                                    lifecycleScope.launch {
                                        prefsRepo.updateAlarmConfig(id, updatedConfig)
                                    }
                                },
                                onSelectAudio = { prayerId ->
                                    activeCustomAudioPrayerId = prayerId
                                    audioPickerLauncher.launch("audio/*")
                                },
                                onPreviewAudio = { mode, uriStr ->
                                    // preview logic
                                }
                            )
                        }
                        composable("settings") {
                            SettingsScreen(
                                userSettings = userSettings,
                                onBack = { navController.popBackStack() },
                                onUpdateGps = { useGps ->
                                    lifecycleScope.launch {
                                        prefsRepo.updateLocation(useGps, userSettings.selectedDistrict, userSettings.latitude, userSettings.longitude)
                                    }
                                },
                                onSelectDistrict = { name, lat, lng ->
                                    lifecycleScope.launch {
                                        prefsRepo.updateLocation(false, name, lat, lng)
                                    }
                                },
                                onUpdateCalculationMethod = { mId ->
                                    lifecycleScope.launch {
                                        prefsRepo.updateCalculationSettings(mId, userSettings.asrSchool)
                                    }
                                },
                                onUpdateAsrSchool = { sId ->
                                    lifecycleScope.launch {
                                        prefsRepo.updateCalculationSettings(userSettings.calculationMethodId, sId)
                                    }
                                },
                                onUpdateNumerals = { useBn ->
                                    lifecycleScope.launch {
                                        prefsRepo.updateBengaliNumerals(useBn)
                                    }
                                }
                            )
                        }
                        composable("diagnostics") {
                            DiagnosticsScreen(
                                lastSyncTimestamp = userSettings.lastSyncTimestamp,
                                lastSyncStatus = userSettings.lastSyncStatus,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}