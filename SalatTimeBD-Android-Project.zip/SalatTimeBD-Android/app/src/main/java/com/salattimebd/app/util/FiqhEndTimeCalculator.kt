package com.salattimebd.app.util

import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

data class PrayerTiming(
    val id: String,
    val nameBn: String,
    val nameEn: String,
    val startTime: String,
    val endTime: String,
    val endRuleType: EndRuleType,
    val fiqhRuleDescriptionBn: String,
    val isObligatory: Boolean = true
)

enum class EndRuleType {
    EXACT_ASTRONOMICAL,
    SUCCESSIVE_START,
    CALCULATED_ESTIMATE
}

object FiqhEndTimeCalculator {
    fun calculatePrayerBoundaries(
        fajr: String,
        sunrise: String,
        dhuhr: String,
        asr: String,
        maghrib: String,
        isha: String,
        nextDayFajr: String? = null,
        asrSchool: String = "Hanafi"
    ): List<PrayerTiming> {
        val cleanFajr = fajr.split(" ")[0].trim()
        val cleanSunrise = sunrise.split(" ")[0].trim()
        val cleanDhuhr = dhuhr.split(" ")[0].trim()
        val cleanAsr = asr.split(" ")[0].trim()
        val cleanMaghrib = maghrib.split(" ")[0].trim()
        val cleanIsha = isha.split(" ")[0].trim()

        val fajrTiming = PrayerTiming(
            id = "fajr",
            nameBn = "ফজর",
            nameEn = "Fajr",
            startTime = cleanFajr,
            endTime = cleanSunrise,
            endRuleType = EndRuleType.EXACT_ASTRONOMICAL,
            fiqhRuleDescriptionBn = "ফজরের ওয়াক্ত সুবহে সাদিক থেকে শুরু হয়ে সূর্যোদয়ের পূর্ব মুহূর্ত পর্যন্ত থাকে। সূর্যোদয় হওয়া মাত্র ফজরের ওয়াক্ত শেষ এবং নামাজ নিষিদ্ধ।"
        )

        val sunriseTiming = PrayerTiming(
            id = "sunrise",
            nameBn = "সূর্যোদয়",
            nameEn = "Sunrise",
            startTime = cleanSunrise,
            endTime = addMinutes(cleanSunrise, 15),
            endRuleType = EndRuleType.EXACT_ASTRONOMICAL,
            fiqhRuleDescriptionBn = "সূর্যোদয়ের সময় থেকে পরবর্তী ১৫-২০ মিনিট পর্যন্ত যে কোনো নামাজ আদায় করা মাকরূহে তাহরীমী (নিষিদ্ধ)।",
            isObligatory = false
        )

        val dhuhrFiqh = if (asrSchool == "Hanafi") {
            "হানাফী মাযহাব অনুযায়ী মূল ছায়া বাদে বস্তুর ছায়া দ্বিগুণ হলে যোহরের ওয়াক্ত শেষ হয়ে আসর শুরু হয়।"
        } else {
            "শাফেয়ী, মালেকী ও হাম্বলী মাযহাব অনুযায়ী মূল ছায়া বাদে বস্তুর ছায়া একগুণ হলে যোহর শেষ হয়ে আসর শুরু হয়।"
        }

        val dhuhrTiming = PrayerTiming(
            id = "dhuhr",
            nameBn = "যোহর",
            nameEn = "Dhuhr",
            startTime = cleanDhuhr,
            endTime = cleanAsr,
            endRuleType = EndRuleType.SUCCESSIVE_START,
            fiqhRuleDescriptionBn = "$dhuhrFiqh নির্বাচিত আসর পদ্ধতি অনুসারে ওয়াক্ত নির্ধারিত।"
        )

        val asrTiming = PrayerTiming(
            id = "asr",
            nameBn = "আসর",
            nameEn = "Asr",
            startTime = cleanAsr,
            endTime = cleanMaghrib,
            endRuleType = EndRuleType.EXACT_ASTRONOMICAL,
            fiqhRuleDescriptionBn = "আসরের ওয়াক্ত সূর্যাস্ত পর্যন্ত থাকে। তবে সূর্যাস্তের ১৫-২০ মিনিট পূর্ব থেকে সূর্য হলুদ বর্ণ ধারণ করলে নামাজ পড়া মাকরূহ। এর পূর্বেই আদায় উত্তম।"
        )

        val maghribTiming = PrayerTiming(
            id = "maghrib",
            nameBn = "মাগরিব",
            nameEn = "Maghrib",
            startTime = cleanMaghrib,
            endTime = cleanIsha,
            endRuleType = EndRuleType.CALCULATED_ESTIMATE,
            fiqhRuleDescriptionBn = "মাগরিবের ওয়াক্ত পশ্চিম আকাশের শাফাক মিলিয়ে যাওয়া পর্যন্ত থাকে, যা এশার ওয়াক্ত শুরু পর্যন্ত স্থায়ী হয় (আনুমানিক হিসাব)। অবিলম্বে নামাজ পড়া মুস্তাহাব।"
        )

        val islamicMidnight = calculateIslamicMidnight(cleanMaghrib, nextDayFajr ?: cleanFajr)
        val ishaTiming = PrayerTiming(
            id = "isha",
            nameBn = "এশা",
            nameEn = "Isha",
            startTime = cleanIsha,
            endTime = islamicMidnight,
            endRuleType = EndRuleType.CALCULATED_ESTIMATE,
            fiqhRuleDescriptionBn = "সহীহ হাদীস অনুযায়ী এশার মুস্তাহাব ওয়াক্ত মধ্যরাত ($islamicMidnight) পর্যন্ত। মধ্যরাতের পর বিলম্ব মাকরূহ, যদিও চূড়ান্ত বৈধ ওয়াক্ত সুবহে সাদিক ($cleanFajr) পর্যন্ত থাকে।"
        )

        return listOf(fajrTiming, sunriseTiming, dhuhrTiming, asrTiming, maghribTiming, ishaTiming)
    }

    fun calculateIslamicMidnight(sunsetTime: String, fajrTime: String): String {
        return try {
            val sunsetParts = sunsetTime.split(":").map { it.toInt() }
            val fajrParts = fajrTime.split(":").map { it.toInt() }
            val sunsetMin = sunsetParts[0] * 60 + sunsetParts[1]
            var fajrMin = fajrParts[0] * 60 + fajrParts[1]
            if (fajrMin < sunsetMin) fajrMin += 24 * 60
            val midnightMin = (sunsetMin + (fajrMin - sunsetMin) / 2) % (24 * 60)
            String.format(Locale.US, "%02d:%02d", midnightMin / 60, midnightMin % 60)
        } catch (e: Exception) {
            "23:45"
        }
    }

    private fun addMinutes(time: String, minutes: Int): String {
        return try {
            val parts = time.split(":").map { it.toInt() }
            val totalMin = (parts[0] * 60 + parts[1] + minutes) % (24 * 60)
            String.format(Locale.US, "%02d:%02d", totalMin / 60, totalMin % 60)
        } catch (e: Exception) {
            time
        }
    }
}